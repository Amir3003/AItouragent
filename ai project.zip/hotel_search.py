"""Модели, моковые данные и локальный поиск отелей для Zari Travel.

Каталог: ровно 50 отелей = 10 направлений х 5 отелей. Каждый отель — отдельная строка с уникальным именем,
ценой и набором номеров.
"""

import json
import os
from datetime import date
from enum import Enum
from typing import Any, Dict, List, Optional

try:
    from openai import OpenAI
except ImportError:  # AI-агент (run_tour_agent) не обязателен для работы API
    OpenAI = None  # type: ignore[assignment]

from pydantic import BaseModel, Field, field_validator, model_validator

from hotel_database import initialize_database, reset_database, search_database


class Amenity(str, Enum):
    """Строгий список удобств, поддерживаемых поиском."""

    PRIVATE_BEACH = "свой пляж"
    SANDY_BEACH = "песчаный пляж"
    FIRST_LINE = "первая линия"
    WIFI = "wifi"
    WATERPARK = "аквапарк"
    KIDS_CLUB = "детский клуб"
    ALL_INCLUSIVE = "все включено"


class MealType(str, Enum):
    """Доступные варианты питания."""

    AI = "AI - Все включено"
    UAI = "UAI - Ультра все включено"
    FB = "FB - Полный пансион"
    BB = "BB - Завтраки"


COUNTRIES: List[str] = [
    "Турция", "Египет", "ОАЭ", "Таиланд", "Мальдивы", "Вьетнам", "Грузия", "Шри-Ланка", "Индонезия", "Испания",
]


class HotelSearchRequest(BaseModel):
    """Параметры, которые приходят от формы поиска или AI-агента."""

    city_from: str = Field(min_length=2, description="Город вылета")
    date_start: str = Field(description="Дата вылета в формате YYYY-MM-DD")
    budget_kzt: int = Field(gt=0, description="Максимальный бюджет всего тура")
    country: Optional[str] = Field(default=None, description="Страна отдыха")
    nights: int = Field(ge=1, le=30, description="Количество ночей")
    adults: int = Field(default=2, ge=1, le=6, description="Количество взрослых")
    children: int = Field(default=0, ge=0, le=4, description="Количество детей")
    children_ages: List[int] = Field(
        default_factory=list,
        description="Возраст каждого ребенка",
    )
    stars: Optional[int] = Field(default=None, description="Минимальная звездность")
    meal_type: Optional[MealType] = Field(default=None, description="Тип питания")
    amenities: List[Amenity] = Field(
        default_factory=list,
        description="Желаемые удобства",
    )

    @field_validator("city_from", mode="before")
    @classmethod
    def normalize_city_from(cls, value: Any) -> Any:
        """Убирает пробелы по краям и приводит город к Title Case."""

        return value.strip().title() if isinstance(value, str) else value

    @field_validator("country", mode="before")
    @classmethod
    def normalize_country(cls, value: Any) -> Any:
        """Нормализует страну по каноническим именам."""

        if not isinstance(value, str):
            return value
        text = value.strip()
        if not text:
            return None

        normalized = text.lower()
        mapping = {
            "турция": "Турция",
            "турции": "Турция",
            "египет": "Египет",
            "египте": "Египет",
            "оаэ": "ОАЭ",
            "эмираты": "ОАЭ",
            "арабские эмираты": "ОАЭ",
            "дубай": "ОАЭ",
            "uae": "ОАЭ",
            "united arab emirates": "ОАЭ",
            "таиланд": "Таиланд",
            "таиланде": "Таиланд",
            "вьетнам": "Вьетнам",
            "вьетнаме": "Вьетнам",
            "мальдивы": "Мальдивы",
            "грузия": "Грузия",
            "шри-ланка": "Шри-Ланка",
            "индонезия": "Индонезия",
            "испания": "Испания",
        }
        return mapping.get(normalized, text)

    @field_validator("date_start")
    @classmethod
    def validate_date_start(cls, value: str) -> str:
        """Проверяет, что дата существует и записана как YYYY-MM-DD."""

        try:
            date.fromisoformat(value)
        except ValueError as error:
            raise ValueError("Дата должна быть в формате YYYY-MM-DD") from error
        return value

    @field_validator("stars")
    @classmethod
    def validate_stars(cls, value: Optional[int]) -> Optional[int]:
        """Оставляет только поддерживаемые категории звездности."""

        if value is not None and value not in {3, 4, 5}:
            raise ValueError("Звездность должна быть 3, 4 или 5")
        return value

    @field_validator("children_ages")
    @classmethod
    def validate_children_ages(cls, value: List[int]) -> List[int]:
        """Проверяет реалистичный возраст детей для семейного поиска."""

        if any(age < 0 or age > 17 for age in value):
            raise ValueError("Возраст ребенка должен быть от 0 до 17 лет")
        return value

    @model_validator(mode="after")
    def validate_family(self) -> "HotelSearchRequest":
        """Синхронизирует число детей со списком их возрастов."""

        if len(self.children_ages) != self.children:
            raise ValueError("Укажите возраст каждого ребенка")
        return self


class RoomOption(BaseModel):
    """Номер, который можно выбрать внутри карточки отеля."""

    id: str
    name: str
    images: List[str] = Field(min_length=5, max_length=5)
    description: str
    sqm: int = Field(ge=10, le=500)
    capacity: str
    amenities_included: List[str] = Field(default_factory=list)
    amenities_excluded: List[str] = Field(default_factory=list)
    vip_privileges: List[str] = Field(default_factory=list)
    price_delta_kzt: int = Field(ge=0)
    availability: str


class HotelRecommendation(BaseModel):
    """Расширенная карточка отеля для API и фронтенда."""

    id: str
    hotel_name: str
    country_city: str
    image_url: str
    stars: int = Field(ge=3, le=5)
    meal_type: str
    price_per_night_kzt: int = Field(gt=0)
    total_price_kzt: int = Field(gt=0)
    rating: float = Field(ge=0, le=5)
    reviews_count: int = Field(ge=0)
    seats_flight: str
    seats_hotel: str
    pros: List[str] = Field(min_length=3, max_length=3)
    cons: List[str] = Field(min_length=1, max_length=2)
    matched_amenities: List[Amenity] = Field(default_factory=list)
    match_score: int = Field(default=0, ge=0, le=100)
    highlight_badge: str = Field(default="⭐ Высший рейтинг")
    summary: str
    room_options: List[RoomOption] = Field(min_length=5, max_length=5)


class MockHotel(BaseModel):
    """Внутренняя запись моковой базы с данными для фильтрации."""

    id: str
    hotel_name: str
    country: str
    country_city: str
    image_url: str
    stars: int
    meal_type: MealType
    package_price_kzt: int
    rating: float
    reviews_count: int
    seats_flight: str
    seats_hotel: str
    amenities: List[Amenity]
    pros: List[str]
    cons: List[str]
    departure_cities: List[str]
    max_guests: int
    summary: str
    room_options: List[RoomOption] = Field(min_length=5, max_length=5)


_HOTEL_IMAGE_POOL = [
    "photo-1564501049412-61c2a3083791", "photo-1540541338287-41700207dee6",
    "photo-1571896349842-33c89424de2d", "photo-1518684079-3c830dcef090",
    "photo-1539367628448-4bc5c9d171c8", "photo-1571003123894-1f0594d2b5d9",
    "photo-1560347876-aeef00ee58a1", "photo-1571902943202-507ec2618e8f",
    "photo-1445019980597-93fa8acb246c", "photo-1602002418082-a4443e081dd1",
]

_ROOM_IMAGE_POOL = [
    "photo-1611892440504-42a792e24d32", "photo-1590490360182-c33d57733427",
    "photo-1587985064135-0366536eab42", "photo-1566665797739-1674de7a421a",
    "photo-1595576508898-0ad5c879a061", "photo-1582719478250-c89cae4dc85b",
]


def _unsplash(photo_id: str) -> str:
    return f"https://images.unsplash.com/{photo_id}?auto=format&fit=crop&w=1200&h=800&q=80"


def _hotel_cover(global_index: int) -> str:
    return _unsplash(_HOTEL_IMAGE_POOL[global_index % len(_HOTEL_IMAGE_POOL)])


def _room_gallery(global_index: int, tier_index: int) -> List[str]:
    start = (global_index * 3 + tier_index * 2) % len(_ROOM_IMAGE_POOL)
    return [
        _unsplash(_ROOM_IMAGE_POOL[(start + step) % len(_ROOM_IMAGE_POOL)])
        for step in range(5)
    ]


_PROS_POOL = [
    "Отель в шаговой доступности от моря",
    "Собственная охраняемая пляжная линия",
    "Насыщенная анимационная программа для детей",
    "Высокий уровень персонала",
    "Современный SPA и бассейн с подогревом",
]

_CONS_POOL = [
    "Доплата за номера с видом на море",
    "В высокий сезон территория может быть многолюдной",
]

_ROOM_TIER_TEMPLATE = [
    ("Standard Garden View", "Уютный номер с видом на сад", 2, 0.0, False),
    ("Superior Sea View", "Светлый номер с видом на море", 3, 0.08, True),
    ("Family Room", "Просторный номер для семейного отдыха", 4, 0.18, True),
    ("Junior Suite", "Отдельная зона отдыха и панорамный вид", 3, 0.32, True),
    ("Presidential Suite", "Премиальный люкс с отдельной гостиной", 4, 0.55, True),
]


def _round_to_thousand(value: float) -> int:
    return int(round(value / 1000.0)) * 1000


def _build_room_options(global_index: int, base_price: int, stars: int) -> List[RoomOption]:
    rooms: List[RoomOption] = []
    for tier_index, (name, description, capacity, price_share, has_kids) in enumerate(_ROOM_TIER_TEMPLATE):
        sqm = 32 + tier_index * 16 + (8 if stars == 5 else 0)
        capacity_text = f"До {capacity} взрослых"
        rooms.append(
            RoomOption(
                id=f"{global_index + 1:03d}-room-{tier_index + 1}",
                name=name,
                images=_room_gallery(global_index, tier_index),
                description=description,
                sqm=sqm,
                capacity=capacity_text,
                amenities_included=["Кондиционер", "Мини-бар", "Сейф", "Wi-Fi"],
                amenities_excluded=[],
                vip_privileges=[],
                price_delta_kzt=_round_to_thousand(base_price * price_share),
                availability="Есть места",
            )
        )
    return rooms


# Каталог: 10 направлений по 5 отелей = ровно 50 качественных записей
_DESTINATIONS: List[Dict[str, Any]] = [
    {
        "country": "Турция", "resort": "Анталья / Белек", "default_meal": MealType.AI,
        "base_amenities": [Amenity.WIFI, Amenity.SANDY_BEACH, Amenity.FIRST_LINE, Amenity.ALL_INCLUSIVE],
        "hotels": [
            ("Rixos Premium Belek", 5, 950000, None, [Amenity.PRIVATE_BEACH, Amenity.WATERPARK, Amenity.KIDS_CLUB]),
            ("Maxx Royal Belek Golf Resort", 5, 1450000, None, [Amenity.PRIVATE_BEACH]),
            ("Delphin Imperial Lara", 5, 890000, None, [Amenity.WATERPARK, Amenity.KIDS_CLUB]),
            ("Titanic Mardan Palace", 5, 1120000, None, [Amenity.PRIVATE_BEACH]),
            ("Barut Hemera", 4, 720000, MealType.UAI, []),
        ],
    },
    {
        "country": "Египет", "resort": "Шарм-эль-Шейх", "default_meal": MealType.AI,
        "base_amenities": [Amenity.WIFI, Amenity.SANDY_BEACH, Amenity.FIRST_LINE, Amenity.ALL_INCLUSIVE],
        "hotels": [
            ("Rixos Premium Seagate", 5, 980000, None, [Amenity.PRIVATE_BEACH, Amenity.WATERPARK]),
            ("Baron Palms Resort", 5, 870000, None, [Amenity.PRIVATE_BEACH]),
            ("Steigenberger Al Dau Beach", 5, 790000, MealType.UAI, [Amenity.KIDS_CLUB]),
            ("Savoy Sharm El Sheikh", 5, 1020000, None, [Amenity.PRIVATE_BEACH]),
            ("Pickalbatros Aqua Blu", 4, 650000, MealType.FB, [Amenity.WATERPARK]),
        ],
    },
    {
        "country": "ОАЭ", "resort": "Дубай", "default_meal": MealType.BB,
        "base_amenities": [Amenity.WIFI, Amenity.SANDY_BEACH],
        "hotels": [
            ("Atlantis The Palm", 5, 1980000, None, [Amenity.FIRST_LINE, Amenity.WATERPARK, Amenity.KIDS_CLUB]),
            ("Jumeirah Beach Hotel", 5, 1620000, None, [Amenity.FIRST_LINE, Amenity.WATERPARK]),
            ("One&Only Royal Mirage", 5, 2150000, None, [Amenity.PRIVATE_BEACH, Amenity.FIRST_LINE]),
            ("Address Beach Resort", 5, 1780000, None, [Amenity.FIRST_LINE]),
            ("Rixos Premium Dubai JBR", 5, 1380000, MealType.AI, [Amenity.FIRST_LINE, Amenity.ALL_INCLUSIVE]),
        ],
    },
    {
        "country": "Таиланд", "resort": "Пхукет", "default_meal": MealType.BB,
        "base_amenities": [Amenity.WIFI, Amenity.SANDY_BEACH],
        "hotels": [
            ("Katathani Phuket Beach Resort", 5, 980000, None, [Amenity.FIRST_LINE, Amenity.KIDS_CLUB]),
            ("Centara Grand Beach Resort", 5, 890000, MealType.AI, [Amenity.FIRST_LINE, Amenity.WATERPARK]),
            ("Angsana Laguna Phuket", 5, 940000, None, [Amenity.WATERPARK, Amenity.KIDS_CLUB]),
            ("Amari Phuket", 4, 780000, None, [Amenity.KIDS_CLUB]),
            ("Banyan Tree Phuket", 5, 1780000, None, [Amenity.PRIVATE_BEACH]),
        ],
    },
    {
        "country": "Мальдивы", "resort": "Мале", "default_meal": MealType.AI,
        "base_amenities": [Amenity.WIFI, Amenity.PRIVATE_BEACH, Amenity.ALL_INCLUSIVE],
        "hotels": [
            ("Soneva Fushi", 5, 2320000, None, [Amenity.PRIVATE_BEACH]),
            ("The Westin Maldives", 5, 2140000, None, [Amenity.PRIVATE_BEACH]),
            ("Kuramathi Maldives", 4, 1680000, None, [Amenity.FIRST_LINE]),
            ("Lily Beach Resort", 5, 1880000, None, [Amenity.WATERPARK]),
            ("Bandos Maldives", 4, 1420000, None, [Amenity.PRIVATE_BEACH]),
        ],
    },
    {
        "country": "Вьетнам", "resort": "Дананг", "default_meal": MealType.BB,
        "base_amenities": [Amenity.WIFI, Amenity.SANDY_BEACH],
        "hotels": [
            ("InterContinental Danang", 5, 1950000, None, [Amenity.PRIVATE_BEACH, Amenity.FIRST_LINE]),
            ("Furama Resort Danang", 5, 890000, None, [Amenity.FIRST_LINE, Amenity.KIDS_CLUB]),
            ("Vinpearl Resort & Spa", 5, 780000, MealType.AI, [Amenity.WATERPARK, Amenity.ALL_INCLUSIVE]),
            ("Hyatt Regency Danang", 5, 1120000, None, [Amenity.FIRST_LINE]),
            ("Naman Retreat", 5, 980000, None, [Amenity.FIRST_LINE]),
        ],
    },
    {
        "country": "Грузия", "resort": "Батуми", "default_meal": MealType.BB,
        "base_amenities": [Amenity.WIFI, Amenity.SANDY_BEACH],
        "hotels": [
            ("Radisson Blu Hotel Batumi", 5, 880000, None, [Amenity.FIRST_LINE]),
            ("Euphoria Hotel Batumi", 4, 760000, MealType.AI, [Amenity.WATERPARK]),
            ("Courtyard by Marriott", 4, 920000, None, []),
            ("Le Meridian Batumi", 5, 980000, None, [Amenity.PRIVATE_BEACH]),
            ("Georgia Palace Hotel", 5, 850000, None, [Amenity.KIDS_CLUB]),
        ],
    },
    {
        "country": "Шри-Ланка", "resort": "Бентота", "default_meal": MealType.BB,
        "base_amenities": [Amenity.WIFI, Amenity.SANDY_BEACH],
        "hotels": [
            ("Taj Bentota Resort & Spa", 5, 980000, None, [Amenity.PRIVATE_BEACH, Amenity.FIRST_LINE]),
            ("Cinnamon Bey Beruwala", 5, 890000, MealType.AI, [Amenity.WATERPARK]),
            ("Pandanus Beach Resort", 4, 780000, None, []),
            ("Heritance Ahungalla", 5, 1050000, None, [Amenity.PRIVATE_BEACH]),
            ("Anantara Peace Haven", 5, 1450000, None, [Amenity.PRIVATE_BEACH]),
        ],
    },
    {
        "country": "Индонезия", "resort": "Бали", "default_meal": MealType.BB,
        "base_amenities": [Amenity.WIFI, Amenity.SANDY_BEACH],
        "hotels": [
            ("Ayana Resort Bali", 5, 1650000, None, [Amenity.PRIVATE_BEACH]),
            ("Mulia Resort Bali", 5, 1540000, None, [Amenity.FIRST_LINE]),
            ("Hard Rock Hotel Bali", 4, 875000, None, [Amenity.KIDS_CLUB]),
            ("Padma Resort Bali", 5, 1200000, None, [Amenity.PRIVATE_BEACH]),
            ("Grand Hyatt Bali", 5, 1420000, None, [Amenity.WATERPARK]),
        ],
    },
    {
        "country": "Испания", "resort": "Барселона", "default_meal": MealType.BB,
        "base_amenities": [Amenity.WIFI, Amenity.SANDY_BEACH],
        "hotels": [
            ("W Barcelona", 5, 1720000, None, [Amenity.FIRST_LINE]),
            ("Hotel Arts Barcelona", 5, 1880000, None, [Amenity.PRIVATE_BEACH]),
            ("Iberostar Selection", 4, 990000, MealType.AI, [Amenity.ALL_INCLUSIVE]),
            ("Mandarin Oriental Barcelona", 5, 1950000, None, []),
            ("Hotel Marina", 4, 860000, None, []),
        ],
    },
]


def _make_hotel_specs() -> List[Dict[str, Any]]:
    specs: List[Dict[str, Any]] = []
    global_index = 0
    for destination in _DESTINATIONS:
        country = destination["country"]
        resort = destination["resort"]
        default_meal: MealType = destination["default_meal"]
        base_amenities: List[Amenity] = destination["base_amenities"]

        for hotel_index, (name, stars, base_price, meal_override, extra_amenities) in enumerate(destination["hotels"]):
            meal_type = meal_override or default_meal
            amenities = list(dict.fromkeys(base_amenities + extra_amenities))
            
            specs.append({
                "id": f"htl-{global_index + 1:03d}",
                "hotel_name": name,
                "country": country,
                "country_city": f"{country}, {resort}",
                "image_url": _hotel_cover(global_index),
                "stars": stars,
                "meal_type": meal_type,
                "package_price_kzt": base_price,
                "rating": round(4.5 + (global_index % 5) / 10, 1),
                "reviews_count": 540 + global_index * 15,
                "seats_flight": "Есть места",
                "seats_hotel": "Мгновенное подтверждение",
                "amenities": amenities,
                "pros": [_PROS_POOL[global_index % len(_PROS_POOL)], _PROS_POOL[(global_index + 1) % len(_PROS_POOL)]],
                "cons": [_CONS_POOL[global_index % len(_CONS_POOL)]],
                "departure_cities": ["Астана", "Алматы"],
                "max_guests": 6,
                "summary": f"{name} — отличный выбор для отдыха в регионе {resort}: {stars}★, {meal_type.value}.",
                "room_options": _build_room_options(global_index, base_price, stars),
            })
            global_index += 1
    return specs


MOCK_HOTELS: List[MockHotel] = [MockHotel(**spec) for spec in _make_hotel_specs()]

reset_database()
initialize_database(MOCK_HOTELS)


def mock_search_tourvisor_api(request: HotelSearchRequest) -> List[HotelRecommendation]:
    recommendations: List[HotelRecommendation] = []
    requested_amenities = set(request.amenities)

    for row in search_database(request):
        amenities = [Amenity(value) for value in json.loads(row["amenities_json"])]
        match_score = 85
        if request.country and row["country"] == request.country:
            match_score += 10

        recommendations.append(
            HotelRecommendation(
                id=row["hotel_id"],
                hotel_name=row["hotel_name"],
                country_city=row["country_city"],
                image_url=row["image_url"],
                stars=row["stars"],
                meal_type=row["meal_type"],
                price_per_night_kzt=round(row["total_price_kzt"] / request.nights),
                total_price_kzt=row["total_price_kzt"],
                rating=row["rating"],
                reviews_count=row["reviews_count"],
                seats_flight=row["seats_flight"],
                seats_hotel=row["seats_hotel"],
                pros=json.loads(row["pros_json"]),
                cons=json.loads(row["cons_json"]),
                matched_amenities=amenities,
                match_score=match_score,
                summary=row["summary"],
                room_options=[
                    RoomOption.model_validate(room)
                    for room in json.loads(row["room_options_json"])
                ],
            )
        )
    return recommendations


def _model_json_schema(model: type[BaseModel]) -> Dict[str, Any]:
    return model.model_json_schema() if hasattr(model, "model_json_schema") else model.schema()


def _model_validate(model: type[BaseModel], value: Any) -> BaseModel:
    return model.model_validate(value) if hasattr(model, "model_validate") else model.parse_obj(value)


def _model_dump(model: BaseModel) -> Dict[str, Any]:
    return model.model_dump(mode="json") if hasattr(model, "model_dump") else json.loads(model.json())


def _build_search_tool() -> Dict[str, Any]:
    return {
        "type": "function",
        "function": {
            "name": "search_hotels",
            "description": "Найти отель по параметрам семейного тура.",
            "parameters": _model_json_schema(HotelSearchRequest),
        },
    }